"""
cluster_analysis.py
====================
UNSUPERVISED ML STEP.

Pools every real historical color (SS25 -> AW26/27, 4 seasons, 16 color
instances) into CIELab space and runs K-Means to discover whether there
are persistent "color families" running underneath the named trend labels
(e.g. is there always a blue/teal anchor? a warm neutral? a pink/red pop?).

Then classifies the REAL held-out SS27 palette (not used to fit the
clusters) against those families: does each SS27 color land inside an
existing family (=continuity/evolution) or far from all of them (=a
genuine break in the trend)?
"""
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'data'))

import numpy as np
from sklearn.cluster import KMeans
from color_utils import hex_to_rgb, rgb_to_lab, delta_e76, lab_to_rgb, rgb_to_hex
from dataset import SEASONS, HELD_OUT_SS27


def pooled_training_colors():
    """All named colors from seasons 0-3 (SS25 through AW26/27)."""
    rows = []
    for t, season in SEASONS.items():
        for name, hexv in season["colors"].items():
            rows.append({
                "season": season["label"],
                "t": t,
                "name": name,
                "hex": hexv,
                "lab": rgb_to_lab(hex_to_rgb(hexv)),
            })
    return rows


def run_clustering(k=5, seed=42):
    rows = pooled_training_colors()
    X = np.array([r["lab"] for r in rows])

    km = KMeans(n_clusters=k, random_state=seed, n_init=10)
    labels = km.fit_predict(X)
    centers = km.cluster_centers_

    clusters = {i: [] for i in range(k)}
    for row, lab in zip(rows, labels):
        clusters[lab].append(row)

    return clusters, centers, rows


def classify_held_out(centers):
    """For each real SS27 color, find nearest existing cluster family."""
    results = []
    for name, hexv in HELD_OUT_SS27["colors"].items():
        rgb = hex_to_rgb(hexv)
        lab = rgb_to_lab(rgb)
        dists = [delta_e76(lab_to_rgb(lab), lab_to_rgb(tuple(c))) for c in centers]
        nearest = int(np.argmin(dists))
        results.append({
            "name": name,
            "hex": hexv,
            "nearest_cluster": nearest,
            "distance_to_family": dists[nearest],
        })
    return results


def describe(k=5):
    clusters, centers, rows = run_clustering(k=k)
    print(f"\n=== UNSUPERVISED CLUSTERING: {k} color families across SS25-AW26/27 ===\n")
    for i, members in clusters.items():
        center_hex = rgb_to_hex(lab_to_rgb(tuple(centers[i])))
        names = ", ".join(f'{m["name"]} ({m["season"]})' for m in members)
        print(f"Family {i}  [center ~ {center_hex}]:")
        print(f"   {names}\n")

    print("=== Classifying the REAL held-out SS27 palette against these families ===\n")
    classification = classify_held_out(centers)
    for c in classification:
        verdict = "CONTINUITY (fits an existing family)" if c["distance_to_family"] < 15 else \
                  "PARTIAL SHIFT (loosely related)" if c["distance_to_family"] < 25 else \
                  "BREAK (genuinely novel direction)"
        print(f"{c['name']:45s} -> Family {c['nearest_cluster']}  "
              f"ΔE={c['distance_to_family']:.1f}   [{verdict}]")

    return clusters, centers, classification


if __name__ == "__main__":
    describe()
