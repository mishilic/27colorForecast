import sys, os
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'data'))

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

from color_utils import hex_to_rgb, rgb_to_lab
from dataset import SEASONS, HELD_OUT_SS27
from trend_regression import run as run_regression
from cluster_analysis import describe as run_clusters

FIG_DIR = os.path.join(os.path.dirname(__file__), '..', 'figures')
os.makedirs(FIG_DIR, exist_ok=True)


def plot_timeline(reg_results):
    seasons_ordered = [SEASONS[t] for t in sorted(SEASONS.keys())]
    n_seasons = len(seasons_ordered) + 2  # + real SS27 + ML predicted SS27

    fig, axes = plt.subplots(1, n_seasons, figsize=(3 * n_seasons, 4.2))

    for i, season in enumerate(seasons_ordered):
        ax = axes[i]
        colors = list(season["colors"].values())
        names = list(season["colors"].keys())
        n = len(colors)
        for j, (c, name) in enumerate(zip(colors, names)):
            ax.add_patch(mpatches.Rectangle((0, j), 1, 1, color=c))
            ax.text(1.08, j + 0.5, name, va='center', fontsize=8, wrap=True)
        ax.set_xlim(0, 3.2)
        ax.set_ylim(0, max(n, 1))
        ax.set_title(season["label"], fontsize=13, fontweight='bold')
        ax.axis('off')

    # Real SS27
    ax = axes[-2]
    colors = list(HELD_OUT_SS27["colors"].values())
    names = list(HELD_OUT_SS27["colors"].keys())
    for j, (c, name) in enumerate(zip(colors, names)):
        ax.add_patch(mpatches.Rectangle((0, j), 1, 1, color=c))
        ax.text(1.08, j + 0.5, name, va='center', fontsize=8)
    ax.set_xlim(0, 3.2)
    ax.set_ylim(0, len(colors))
    ax.set_title("SS27 (REAL)", fontsize=13, fontweight='bold', color='darkgreen')
    ax.axis('off')

    # ML predicted centroid
    ax = axes[-1]
    ax.add_patch(mpatches.Rectangle((0, 0), 1, 1, color=reg_results["predicted_centroid_hex"]))
    ax.text(1.08, 0.5, "ML-predicted\ncentroid", va='center', fontsize=9)
    ax.add_patch(mpatches.Rectangle((0, 1.3), 1, 1, color=reg_results["predicted_anchor_hex"]))
    ax.text(1.08, 1.8, "ML-predicted\nanchor color", va='center', fontsize=9)
    ax.set_xlim(0, 3.2)
    ax.set_ylim(0, 2.5)
    ax.set_title("ML PREDICTION", fontsize=13, fontweight='bold', color='darkred')
    ax.axis('off')

    plt.tight_layout()
    path = os.path.join(FIG_DIR, "timeline_swatches.png")
    plt.savefig(path, dpi=150, bbox_inches='tight')
    plt.close()
    return path


def plot_trajectory(reg_results):
    ts = reg_results["ts"].flatten()
    labs = reg_results["labs"]

    fig, ax = plt.subplots(figsize=(7, 6))
    ax.plot(labs[:, 1], labs[:, 2], '-o', color='gray', label="Real season centroids (SS25→AW26/27)")
    for t, (a, b) in zip(ts, labs[:, 1:]):
        ax.annotate(SEASONS[t]["label"], (a, b), textcoords="offset points", xytext=(6, 6), fontsize=9)

    from color_utils import rgb_to_lab as _rl, hex_to_rgb as _hr
    pred_lab = _rl(_hr(reg_results["predicted_centroid_hex"]))
    real_lab = _rl(_hr(reg_results["real_centroid_hex"]))

    ax.scatter([pred_lab[1]], [pred_lab[2]], color='red', s=140, marker='X', zorder=5,
               label=f"ML-predicted SS27 (ΔE={reg_results['centroid_delta_e']:.1f})")
    ax.scatter([real_lab[1]], [real_lab[2]], color='green', s=140, marker='*', zorder=5,
               label="REAL published SS27")

    ax.plot([pred_lab[1], real_lab[1]], [pred_lab[2], real_lab[2]], '--', color='crimson', alpha=0.6)

    ax.set_xlabel("a* (green ← → red)")
    ax.set_ylabel("b* (blue ← → yellow)")
    ax.set_title("Color trajectory in CIELab space: prediction vs. reality")
    ax.legend(fontsize=8, loc='best')
    ax.grid(alpha=0.3)
    plt.tight_layout()
    path = os.path.join(FIG_DIR, "lab_trajectory.png")
    plt.savefig(path, dpi=150, bbox_inches='tight')
    plt.close()
    return path


def plot_clusters(clusters, centers):
    from color_utils import lab_to_rgb, rgb_to_hex
    fig, ax = plt.subplots(figsize=(8, 5))
    y = 0
    for i, members in clusters.items():
        center_hex = rgb_to_hex(lab_to_rgb(tuple(centers[i])))
        ax.add_patch(mpatches.Rectangle((0, y), 0.6, 0.8, color=center_hex))
        label = ", ".join(f'{m["name"]}' for m in members)
        ax.text(0.75, y + 0.4, f"Family {i}: {label}", va='center', fontsize=9)
        y += 1.1
    ax.set_xlim(0, 6)
    ax.set_ylim(-0.2, y)
    ax.axis('off')
    ax.set_title("Unsupervised color families found across SS25 → AW26/27", fontsize=12, fontweight='bold')
    plt.tight_layout()
    path = os.path.join(FIG_DIR, "clusters.png")
    plt.savefig(path, dpi=150, bbox_inches='tight')
    plt.close()
    return path


if __name__ == "__main__":
    reg = run_regression()
    clusters, centers, classification = run_clusters()
    p1 = plot_timeline(reg)
    p2 = plot_trajectory(reg)
    p3 = plot_clusters(clusters, centers)
    print("Saved:", p1, p2, p3)
