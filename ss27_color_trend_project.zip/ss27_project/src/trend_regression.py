"""
trend_regression.py
====================
SUPERVISED ML STEP.

For each real season (t=0..3), compute the centroid color (mean L, a, b
across that season's published colors). Fit a linear regression of each
Lab channel against time (t), then extrapolate to t=4 (S/S 2027) to get
an independently-predicted "palette centroid" for Summer 2027.

We also track a single narrower thread -- the recurring "cool anchor"
color present nearly every season (Future Dusk -> Retro Blue ->
Transformative Teal -> Transformative Teal) -- and regress THAT
specifically, since Coloro's own Color-of-the-Year selections
(Luminous Blue for 2027) tend to come from exactly this lineage.

Finally, we score both predictions against the real, already-published
SS27 palette using Delta-E76 -- this is the "evidence" the project is
built to produce: a genuine, falsifiable number, not a vibe.
"""
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'data'))

import numpy as np
from sklearn.linear_model import LinearRegression
from color_utils import hex_to_rgb, rgb_to_lab, lab_to_rgb, rgb_to_hex, delta_e76
from dataset import SEASONS, HELD_OUT_SS27

TARGET_T = 4  # S/S 2027


def season_centroid_lab(season):
    labs = [rgb_to_lab(hex_to_rgb(h)) for h in season["colors"].values()]
    return np.mean(labs, axis=0)


def fit_and_predict_centroid():
    ts = np.array(sorted(SEASONS.keys())).reshape(-1, 1)
    labs = np.array([season_centroid_lab(SEASONS[t]) for t in sorted(SEASONS.keys())])

    preds = []
    models = []
    for channel in range(3):  # L, a, b
        model = LinearRegression()
        model.fit(ts, labs[:, channel])
        models.append(model)
        preds.append(model.predict([[TARGET_T]])[0])

    predicted_lab = tuple(preds)
    predicted_hex = rgb_to_hex(lab_to_rgb(predicted_lab))
    return predicted_lab, predicted_hex, models, ts, labs


# --- The recurring "cool anchor" lineage tracked across seasons ---
COOL_ANCHOR_LINEAGE = {
    0: "#4C4F72",  # Future Dusk, SS25
    1: "#3F6C9E",  # Retro Blue, AW25/26
    2: "#1E7F7A",  # Transformative Teal, SS26
    3: "#1E7F7A",  # Transformative Teal, AW26/27
}


def fit_and_predict_anchor():
    ts = np.array(sorted(COOL_ANCHOR_LINEAGE.keys())).reshape(-1, 1)
    labs = np.array([rgb_to_lab(hex_to_rgb(COOL_ANCHOR_LINEAGE[t]))
                      for t in sorted(COOL_ANCHOR_LINEAGE.keys())])

    preds = []
    for channel in range(3):
        model = LinearRegression()
        model.fit(ts, labs[:, channel])
        preds.append(model.predict([[TARGET_T]])[0])

    predicted_lab = tuple(preds)
    predicted_hex = rgb_to_hex(lab_to_rgb(predicted_lab))
    return predicted_lab, predicted_hex


def real_ss27_centroid():
    labs = [rgb_to_lab(hex_to_rgb(h)) for h in HELD_OUT_SS27["colors"].values()]
    centroid_lab = tuple(np.mean(labs, axis=0))
    return centroid_lab, rgb_to_hex(lab_to_rgb(centroid_lab))


def run():
    pred_centroid_lab, pred_centroid_hex, models, ts, labs = fit_and_predict_centroid()
    real_centroid_lab, real_centroid_hex = real_ss27_centroid()
    centroid_de = delta_e76(lab_to_rgb(pred_centroid_lab), lab_to_rgb(real_centroid_lab))

    pred_anchor_lab, pred_anchor_hex = fit_and_predict_anchor()
    real_blue_hex = HELD_OUT_SS27["colors"]["Luminous Blue (Color of the Year 2027)"]
    anchor_de = delta_e76(lab_to_rgb(pred_anchor_lab), hex_to_rgb(real_blue_hex))

    print("=== SUPERVISED ML: linear extrapolation of the seasonal color trajectory ===\n")
    print(f"ML-predicted S/S 2027 PALETTE CENTROID:  {pred_centroid_hex}")
    print(f"REAL published S/S 2027 palette centroid: {real_centroid_hex}")
    print(f"Delta-E76 between prediction and reality: {centroid_de:.2f}")
    print("  (for reference: <2.3 = imperceptible, 2-10 = noticeable but related,")
    print("   10-25 = clearly different colors, >25 = essentially unrelated)\n")

    print("=== Narrower thread: the recurring 'cool anchor' lineage ===")
    print("Future Dusk -> Retro Blue -> Transformative Teal -> Transformative Teal -> ?")
    print(f"ML-predicted next anchor color:     {pred_anchor_hex}")
    print(f"REAL Color of the Year 2027:        {real_blue_hex}  (Luminous Blue)")
    print(f"Delta-E76 between prediction and reality: {anchor_de:.2f}\n")

    return {
        "predicted_centroid_hex": pred_centroid_hex,
        "real_centroid_hex": real_centroid_hex,
        "centroid_delta_e": centroid_de,
        "predicted_anchor_hex": pred_anchor_hex,
        "real_anchor_hex": real_blue_hex,
        "anchor_delta_e": anchor_de,
        "ts": ts,
        "labs": labs,
    }


if __name__ == "__main__":
    run()
