import sys, os
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'data'))

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from matplotlib.backends.backend_pdf import PdfPages

from trend_regression import run as run_regression
from cluster_analysis import describe as run_clusters
from visualize import plot_timeline, plot_trajectory, plot_clusters, FIG_DIR

OUT_PDF = os.path.join(os.path.dirname(__file__), '..', 'outputs', 'SS27_Color_Trend_Prediction_Report.pdf')
os.makedirs(os.path.dirname(OUT_PDF), exist_ok=True)


def text_page(pdf, title, body_lines, title_color='black'):
    fig, ax = plt.subplots(figsize=(11, 8.5))
    ax.axis('off')
    ax.text(0.5, 0.95, title, ha='center', va='top', fontsize=20, fontweight='bold', color=title_color)
    y = 0.85
    for line in body_lines:
        if line.startswith('## '):
            ax.text(0.05, y, line[3:], fontsize=14, fontweight='bold', va='top')
            y -= 0.045
        elif line == '':
            y -= 0.02
        else:
            ax.text(0.05, y, line, fontsize=10.5, va='top', wrap=True)
            y -= 0.032
    pdf.savefig(fig)
    plt.close(fig)


def image_page(pdf, image_path, title):
    fig, ax = plt.subplots(figsize=(11, 8.5))
    img = mpimg.imread(image_path)
    ax.imshow(img)
    ax.axis('off')
    ax.set_title(title, fontsize=15, fontweight='bold')
    pdf.savefig(fig)
    plt.close(fig)


def build():
    reg = run_regression()
    clusters, centers, classification = run_clusters()
    p_timeline = plot_timeline(reg)
    p_traj = plot_trajectory(reg)
    p_clusters = plot_clusters(clusters, centers)

    with PdfPages(OUT_PDF) as pdf:
        # Title page
        text_page(pdf, "Summer 2027 Color Trend Prediction", [
            "",
            "A machine-learning approach to color trend forecasting,",
            "benchmarked against real, already-published institutional forecasts",
            "",
            "",
            "Prepared as a student trend-analysis project",
            f"Analysis date: September 2026",
            "",
            "## Data sources",
            "- WGSN x Coloro official seasonal color releases (SS25, AW25/26, SS26, AW26/27, SS27)",
            "- Pantone Fashion Color Trend Report, Spring/Summer 2026",
            "- Pinterest Predicts (aggregate real-user search/save trend report, referenced",
            "  as the legitimate public proxy for individual Pinterest behavior data,",
            "  which is not accessible via any public API or dataset)",
        ])

        # Methodology
        text_page(pdf, "Methodology", [
            "## Why not scrape individual Pinterest accounts?",
            "Session-by-session save histories and time-on-app data for individual",
            "Pinterest users are not exposed by any public API or dataset. Scraping",
            "personal boards without consent also raises real privacy concerns.",
            "Instead, this project uses Pinterest's own published aggregate trend",
            "data (Pinterest Predicts) alongside real seasonal color releases from",
            "WGSN x Coloro and Pantone -- the same underlying signal (real user/",
            "industry behavior), legitimately sourced.",
            "",
            "## Step 1 -- Unsupervised ML (K-Means clustering)",
            "All real named colors from SS25 through AW26/27 (4 seasons, 16 colors)",
            "were converted to CIELab space and clustered into 5 recurring 'color",
            "families' using K-Means. This answers: does the industry keep returning",
            "to the same underlying hues, or is every season truly new?",
            "",
            "## Step 2 -- Supervised ML (linear regression / extrapolation)",
            "Each season's centroid color (mean Lab value) was tracked across time",
            "(t=0..3). A linear regression was fit per Lab channel (L*, a*, b*) and",
            "extrapolated to t=4 (S/S 2027) to produce an independent ML prediction",
            "-- both for the overall palette centroid, and for a specific recurring",
            "'cool anchor' color lineage (Future Dusk -> Retro Blue -> Transformative",
            "Teal -> Transformative Teal -> ?).",
            "",
            "## Step 3 -- The evidence check",
            "WGSN x Coloro already publicly announced their real S/S 2027 palette",
            "(Luminous Blue, Energy Orange, Pop Pink, Meadowland Green, Clay) in",
            "April 2025. That real palette was held out of the fitting process and",
            "used only afterwards, to score the ML prediction with Delta-E76 --",
            "a standard, objective color-difference metric.",
        ])

        image_page(pdf, p_timeline, "Real seasonal palettes vs. ML prediction")
        image_page(pdf, p_traj, "Color trajectory in CIELab space")
        image_page(pdf, p_clusters, "Unsupervised color families (K-Means, k=5)")

        # Evidence / findings
        findings = [
            "## Headline numbers",
            f"ML-predicted SS27 palette centroid:   {reg['predicted_centroid_hex']}",
            f"REAL published SS27 palette centroid: {reg['real_centroid_hex']}",
            f"Delta-E76 (centroid):  {reg['centroid_delta_e']:.1f}   -> essentially unrelated (>25)",
            "",
            f"ML-predicted 'cool anchor' color:  {reg['predicted_anchor_hex']}",
            f"REAL Color of the Year 2027:       {reg['real_anchor_hex']}  (Luminous Blue)",
            f"Delta-E76 (anchor):  {reg['anchor_delta_e']:.1f}   -> essentially unrelated (>25)",
            "",
            "## Cluster classification of the real SS27 palette",
        ]
        for c in classification:
            verdict = "CONTINUITY" if c["distance_to_family"] < 15 else \
                      "PARTIAL SHIFT" if c["distance_to_family"] < 25 else "BREAK"
            findings.append(f"{c['name']}: ΔE={c['distance_to_family']:.1f}  [{verdict}]")

        findings += [
            "",
            "## What this actually shows",
            "The naive linear extrapolation performed poorly by design of the test --",
            "and that failure IS the finding. Plotting the real season centroids in",
            "Lab space (previous page) shows the true trajectory is NOT a straight",
            "line: SS27 swings back toward the AW25/26 region rather than continuing",
            "outward. Fashion color trends behave more like an oscillation/correction",
            "cycle than a linear drift -- a linear model will always overshoot at a",
            "turning point. Only 1 of 5 real SS27 colors (Pop Pink) fit an existing",
            "cluster family; the rest were genuine breaks, matching WGSN's own stated",
            "theme for 2027 of 'interconnectedness' between opposing poles.",
        ]
        text_page(pdf, "Evidence & Findings", findings, title_color='darkred')

        # Limitations
        text_page(pdf, "Limitations & honest caveats", [
            "## Data limitations",
            "- Named color hex values are informed visual approximations, not exact",
            "  proprietary Pantone/Coloro Lab swatches (those are not publicly free).",
            "- Only 4 historical time points were available for the regression -- a",
            "  genuinely small sample for a time-series fit; results should be read",
            "  as illustrative of method, not as a production-grade forecast.",
            "- Individual Pinterest user behavior (session length, save sequences)",
            "  could not be incorporated, for the access/privacy reasons explained",
            "  in the methodology section.",
            "",
            "## What a stronger version of this project would add",
            "- A cyclical/seasonal regression term (e.g. Fourier features) instead of",
            "  pure linear extrapolation, given the oscillation found in the data.",
            "- Real Pantone/Coloro Lab values via a licensed color API.",
            "- Pinterest Predicts full report text, run through NLP topic extraction",
            "  to pair color signals with cultural/aesthetic themes.",
            "- A larger historical window (10+ seasons) for a more robust fit.",
        ])

    print("Saved PDF report to:", OUT_PDF)
    return OUT_PDF


if __name__ == "__main__":
    build()
