"""
dataset.py
==========
Real, publicly-published seasonal color trend data from WGSN x Coloro,
used as a chronological time series (SS25 -> AW25/26 -> SS26 -> AW26/27 -> SS27).

IMPORTANT METHODOLOGY NOTE (read this first):
-----------------------------------------------
Individual Pinterest users' private save histories, session-by-session
scroll behavior, and time-on-app data are NOT publicly available through
any API or dataset, and scraping them would raise real privacy concerns
even if they were technically reachable. So instead of fabricating that
data, this project uses a legitimate substitute with the same underlying
logic: real, publicly published seasonal color trend reports from
WGSN x Coloro, tracked chronologically across five real seasons.

This gives us:
  - A genuine TIME SERIES of real institutional color decisions (proxy for
    "how does the palette evolve", just measured across the industry's
    aggregate signal over real seasons instead of one person's session)
  - A genuine HELD-OUT GROUND TRUTH: WGSN/Coloro have already published
    their real S/S 2027 palette (this is public knowledge as of Sept 2026).
    We deliberately do NOT show this to the model when fitting the trend -
    we only use it afterwards to score how close our own from-scratch
    ML extrapolation gets to the real, already-announced answer.

Hex values below are INFORMED APPROXIMATIONS of each named color based on
public descriptions and imagery, not exact proprietary Lab/Coloro values
(Pantone/Coloro do not publish free public RGB conversions of their
proprietary swatches). Treat them as analysis-grade estimates, not
official swatches.

Sources (all public news coverage of official WGSN/Coloro releases):
- FashionUnited: "Coloro and WGSN: The colour trends for SS25"
- FashionUnited: "Spotted on the catwalk: WGSN and Coloro's colour trends for AW26/27"
- FashionUnited: "Spotted on the catwalk: The WGSN spring/summer 2027 colours"
- WWD: "WGSN and Coloro Single Out 'Luminous Blue' as 2027 Color of the Year"
- WGSN.com official press release, April 29 2025 (S/S 27 Key Colours)
- Wunderlabel: "Color Trends 2026: Pantone, Coloro & Fashion Weeks"
"""

# time_index: chronological step, evenly spaced seasons
# 0 = SS25, 1 = AW25/26, 2 = SS26, 3 = AW26/27, 4 = SS27 (HELD OUT / not used for fitting)

SEASONS = {
    0: {
        "label": "SS25",
        "colors": {
            "Future Dusk (Color of the Year 2025)": "#4C4F72",
            "Transcendent Pink": "#E8A7C4",
        },
    },
    1: {
        "label": "AW25/26",
        "colors": {
            "Celestial Yellow": "#F4D35E",
            "Cherry Lacquer": "#7A1F2B",
            "Retro Blue": "#3F6C9E",
            "Neon Flare": "#FF3864",
            "Future Dusk": "#4C4F72",
        },
    },
    2: {
        "label": "SS26",
        "colors": {
            "Transformative Teal": "#1E7F7A",
            "Electric Fuchsia": "#D6249F",
            "Mint": "#A8E6C9",
            "Aqua": "#7FDBDA",
        },
    },
    3: {
        "label": "AW26/27",
        "colors": {
            "Transformative Teal": "#1E7F7A",
            "Wax Paper": "#EDE0C8",
            "Fresh Purple": "#7B4FA0",
            "Cocoa Powder": "#5A3A2E",
            "Green Glow": "#A8C43A",
        },
    },
}

# HELD OUT — the real, already-published SS27 palette. Not used for fitting,
# only for scoring the extrapolation afterwards.
HELD_OUT_SS27 = {
    "label": "SS27 (real, already published)",
    "colors": {
        "Luminous Blue (Color of the Year 2027)": "#2E6FD6",
        "Energy Orange": "#E8622B",
        "Pop Pink": "#F25C9A",
        "Meadowland Green": "#6E8F4E",
        "Clay": "#B97A63",
    },
}

# Supplementary same-season (SS26) Pantone Fashion Color Trend Report colors,
# used as the "Pinterest-summer-2026 proxy" pool for the unsupervised
# clustering step, since these represent what was actually worn/searched/
# saved as the real aesthetic signal of summer 2026.
PANTONE_SS26 = {
    "Lava Red": "#B23A2E",
    "Coffee Bean": "#4A3428",
    "Amaranth": "#6E2C5E",
    "Burnt Sienna": "#A9532E",
    "Burnished Lilac": "#B49CC2",
    "Muskmelon": "#F2915B",
    "Acacia": "#D9DB5C",
    "Cloud Dancer (Color of the Year 2026)": "#F1EEE8",
    "Dusty Rose": "#C99A9A",
    "Cerulean Blue": "#3E7EAE",
}
