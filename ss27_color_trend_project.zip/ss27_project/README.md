# Summer 2027 Color Trend Prediction — ML Project

A student trend-forecasting project: predict the Summer 2027 fashion color
palette using unsupervised + supervised machine learning on real historical
color-trend data, then benchmark the prediction against the real palette
that WGSN x Coloro already published for S/S 2027.

## Important scope note

This project does **not** scrape individual Pinterest users' save histories
or session behavior — that data isn't available through any public API or
dataset, and scraping it would raise real privacy concerns regardless.
Instead it uses **real, publicly published institutional color-trend data**
(WGSN x Coloro seasonal releases, Pantone's Fashion Color Trend Report) as
a legitimate substitute for "how does the palette evolve over time" —
tracked across five real fashion seasons instead of one person's session.
See `data/dataset.py` for full source citations and reasoning.

## Project structure

```
ss27_project/
├── data/
│   └── dataset.py          # Real seasonal color data (SS25 → SS27), with sources
├── src/
│   ├── color_utils.py       # hex/RGB/HSL/Lab conversions, Delta-E76
│   ├── cluster_analysis.py  # UNSUPERVISED ML: K-Means color-family clustering
│   ├── trend_regression.py  # SUPERVISED ML: linear regression + extrapolation
│   ├── visualize.py         # Builds all charts (timeline, Lab trajectory, clusters)
│   └── build_report.py      # Assembles the final PDF report
├── figures/                 # PNG charts (generated)
├── outputs/
│   └── SS27_Color_Trend_Prediction_Report.pdf   # Final report (generated)
└── requirements.txt
```

## Setup (VS Code / terminal)

```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Run everything

```bash
cd src
python3 build_report.py
```

This regenerates all figures in `figures/` and the final PDF in `outputs/`.

You can also run each stage independently to see console output:

```bash
python3 cluster_analysis.py     # unsupervised clustering results
python3 trend_regression.py     # supervised prediction + Delta-E evidence
python3 visualize.py            # just the charts
```

## Headline finding

A naive linear extrapolation of 2025–2026 color trends predicts Summer 2027
would continue toward warm, muted greens. The real WGSN x Coloro answer —
**Luminous Blue** — is a near-total reversal (Delta-E ≈ 84 from the linear
prediction). The color trajectory in Lab space shows real seasonal
centroids oscillating rather than drifting in one direction, which is why
the linear model fails: fashion color trends behave more like a
correction cycle than a straight-line drift. See the PDF report for full
methodology, evidence, and limitations.
